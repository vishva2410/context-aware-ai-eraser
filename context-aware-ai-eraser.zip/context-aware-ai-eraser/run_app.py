import sys
import os

# Ensure the current directory is in the python path
sys.path.append(os.getcwd())

from api.app import app

if __name__ == "__main__":
    print("Starting Context-Aware AI Eraser...")
    print("Open http://127.0.0.1:5000 in your browser.")
    app.run(debug=True, port=5000)
