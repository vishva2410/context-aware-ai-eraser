# Context-Aware AI Eraser

## Setup
1. Install Python 3.8+
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Running
Run the application using the helper script:
```bash
python run_app.py
```

Then open `http://127.0.0.1:5000` in your browser.
